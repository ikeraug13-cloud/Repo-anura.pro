# 🎮 Iker Repo — AnuraOS Marketplace

Repositorio de apps web para [Anura.pro](https://anura.pro) en formato oficial de marketplace.

## 📦 Apps incluidas

| App | Categoría | Package |
|-----|-----------|---------|
| Discord | Social | `social.discord` |
| Instagram | Social | `social.instagram` |
| Reddit | Social | `social.reddit` |
| YouTube | Media | `media.youtube` |
| Spotify | Media | `media.spotify` |
| Photopea | Tools | `tools.photopea` |
| VS Code Web | Development | `dev.vscode` |
| Google Drive | Productivity | `productivity.drive` |

## 🚀 Cómo hostear (GitHub Pages)

1. Sube esta carpeta a un repositorio público de GitHub
2. Ve a **Settings → Pages → Branch: main / root**
3. Tu repo estará en: `https://TU_USUARIO.github.io/iker-repo/`
4. En Anura.pro, ve al Marketplace → ➕ → pega la URL anterior

## 🗂️ Estructura

```
iker-repo/
├── manifest.json        ← info del repo
├── list.json            ← lista de apps
└── apps/
    ├── social.discord/
    │   ├── app.zip      ← app.json + index.html + icon.svg
    │   └── icon.svg
    ├── social.instagram/
    ├── media.youtube/
    └── ...
```
